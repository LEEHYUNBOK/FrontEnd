let j = { name: '홍길동', age: 16 }

let a = [j, j, j]

console.log(a)
