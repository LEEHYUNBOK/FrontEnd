let person = []
for (let i = 0; i < 10; i++) {
  person.push({ name: '홍길동', age: 16 + i })
}

console.log(person)
